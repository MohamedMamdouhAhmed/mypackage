from setuptools import setup, find_packages

setup(
    name='Doo',
    version='0.1',
    packages= find_packages(),  # Use `find_packages()` correctly
    description='NA',  # Replace with a concise description
    long_description='NA',  # Replace with a detailed description (optional)  # Fix typo
    author='Doo',
    author_email='Doo@gmail.com',
)